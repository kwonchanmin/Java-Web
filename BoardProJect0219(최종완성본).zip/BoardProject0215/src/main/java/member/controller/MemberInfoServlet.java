package member.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.service.MemberService;
import member.vo.Member;

/**
 * Servlet implementation class MemberInfoServlet
 */
@WebServlet("/memberinfo")
public class MemberInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id= request.getParameter("id");
		String name = request.getParameter("name");
		String pw = request.getParameter("pw");
		
		Member member = new Member();
		member.setMemberId(id);
		member.setMemberName(name);
		member.setMemberPw(pw);
		
		MemberService service = new MemberService();
		Member result = service.select(member);
		
		if(result != null) {
			HttpSession session = request.getSession(true);
			session.setAttribute("infomember", result);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("memberInfo.jsp");
			request.setAttribute("memberinfo", result);
			
			dispatcher.forward(request, response);
		}else {
			response.sendRedirect("loadingfail.html");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
